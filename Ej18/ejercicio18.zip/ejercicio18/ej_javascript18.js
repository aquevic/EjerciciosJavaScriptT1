let pantalla;
let operacionActual;
let numeroLeido;

window.addEventListener("DOMContentLoaded", () => {
    pantalla = document.getElementById("inputResultado");
    let arrayBotonesNumeros = document.getElementsByClassName("botonNumero");
    let arrayBotonesOperador = document.getElementsByClassName("botonOperador");

    let botonBorrarMemoria = document.getElementById("botonBorrarMemoria");

    let botonIgual = document.getElementById("botonIgual");

    for (let i = 0; i < arrayBotonesNumeros.length; i++) {
        arrayBotonesNumeros[i].addEventListener("click", () => {
            anyadirCaracterAPantalla(arrayBotonesNumeros[i].innerHTML);
        });
    }

    for (let i = 0; i < arrayBotonesOperador.length; i++) {
        arrayBotonesOperador[i].addEventListener("click", () => {
            anyadirOperador(arrayBotonesOperador[i].innerHTML);
        })
    }

    botonBorrarMemoria.addEventListener("click", borrarMemoria);

    botonIgual.addEventListener("click", mostrarOperacion);
})

function anyadirCaracterAPantalla(caracter) {
    if (isNaN(caracter)) {
        alert("Error, no se ha podido añadir el número");
    } else {
        pantalla.value += caracter;
    }
}

function anyadirOperador(caracter) {

    switch (caracter) {
        case '+':
        case 'x':
        case '-':
        case '/':
            if (operacionActual) {
                alert("Ya hay una operación en curso, pulsa igual o borra la memoria para hacer más operaciones");
            } else {
                numeroLeido = parseFloat(pantalla.value);
                operacionActual = caracter;
                pantalla.value = "";
            }

            break;
        default:
            alert("Error, no se ha podido poner el operador");
            break;
    }
}

function borrarMemoria() {
    pantalla.value = "";
    numeroLeido = "";
    operacionActual = "";
}

function mostrarOperacion() {
    if (!numeroLeido) numeroLeido = 0; //Si se hace una operacion sin un numero inicial, este se pondrá como 0 para evitar errores
    
    switch (operacionActual) {
        case '+':
            pantalla.value = numeroLeido + parseFloat(pantalla.value);
            break;
        case 'x':
            pantalla.value = numeroLeido * parseFloat(pantalla.value);
            break;
        case '-':
            pantalla.value = numeroLeido - parseFloat(pantalla.value);
            break;
        case '/':
            if (pantalla.value === "0") { //Si se intenta dividir por 0 borra la memoria y salta error
                alert("Es imposible dividir un numero por 0");
                borrarMemoria();
            } else {
                pantalla.value = numeroLeido / parseFloat(pantalla.value);
            }
            break;
        default:
            alert("Error, no se ha encontrado el operador");
            break;
    }
    
    operacionActual = "";
}